/* sername.h:  Define name for PGPLOT View server */

#define PGV_SERVER_NAME "PGPlot-Server2"
